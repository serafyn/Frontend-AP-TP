package com.portfolioap.backendportfolioap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendportfolioapApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendportfolioapApplication.class, args);
	}

}
