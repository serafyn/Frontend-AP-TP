package com.portfolioap.backendportfolioap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendportfolioapApplicationTests {

	@Test
	void contextLoads() {
	}

}
